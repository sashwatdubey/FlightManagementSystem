package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.User;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	static Logger logger = Logger.getLogger(RegistrationController.class.getName());
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	IUserService service = new UserService();
	int isCreated = 0;
    PrintWriter out = response.getWriter();
	RequestDispatcher dispatcher = null;
	HttpSession session = request.getSession();
	boolean isUserExists = false;
	String userName = request.getParameter("uname");
	String password = request.getParameter("upass");
	Long mobileNumber = Long.parseLong(request.getParameter("umobile"));
	String emailId = request.getParameter("uemail");
	
	try {
			User user = new User(userName, password, mobileNumber, emailId);
			isUserExists = service.isUserExists(emailId);
			logger.info("Is user Exists?:"+isUserExists);
			if(isUserExists) {
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('User already exists. Please login!');");
				   out.println("location='Login.jsp';");
				   out.println("</script>");
				   logger.info("Account already exists! please login");
				   logger.info("control is forwarded to Login.jsp");
			} else {
				isCreated = service.accountCreation(user);
				if (isCreated > 0) {
					   out.println("<script type=\"text/javascript\">");
					   out.println("alert('Registered Successfully! Please login to continue.');");
					   out.println("location='Login.jsp';");
					   out.println("</script>");
					   logger.info("Account Created Successfully!!");
					   logger.info("control is forwarded to Login.jsp");
					
				} else {
					   out.println("<script type=\"text/javascript\">");
					   out.println("alert('Problem occured while registering. Please try again!');");
					   out.println("location='Register.jsp';");
					   out.println("</script>");
					   logger.info("Problem occured while inserting");
					   logger.info("control is forwarded to Register.jsp");
				}
			}
			
	} catch (FMSException e) {
		logger.error("Error while registering user", e);
		session.setAttribute("errorMessage", e.getMessage());
		response.sendRedirect("errorPage.jsp");
	}

	
}
}
