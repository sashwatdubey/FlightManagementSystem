package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/AddPassengersController")
public class AddPassengersController extends HttpServlet{
	static Logger logger = Logger.getLogger(AddPassengersController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IUserService service = new UserService();
		RequestDispatcher dispatcher = null;
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		int passengerCount = Integer.parseInt(request.getParameter("passengerCount"));
		ServletContext context = request.getServletContext();
		int flightNumber = (int)session.getAttribute("flightNumber");
		int userId = Integer.parseInt(""+context.getAttribute("userId"));
		LocalDate now = LocalDate.now(); 
		String bookingDate = now.toString();
		Booking booking = null;
		ScheduleFlight flight = null;
		int availableSeats = 0;
		double cost = 0;
		int makeBooking = 0;
		int isUpdated = 0;
		try {
			flight = service.viewFlightDetails(flightNumber);
			cost = (passengerCount) * flight.getCost();
			booking = new Booking(userId, bookingDate,cost ,passengerCount, "booked", flightNumber);
			logger.debug(booking);
			makeBooking = service.makeBooking(booking);
			context.setAttribute("bookingId", makeBooking);
			context.setAttribute("passengerCount", passengerCount);
			if(makeBooking > 0) {
			logger.debug("Make Booking Value:"+makeBooking);
			availableSeats = flight.getAvailableSeats();
			availableSeats -= (passengerCount);
			isUpdated = service.updateAvailableSeats(availableSeats, flightNumber);
			dispatcher = request.getRequestDispatcher("passengers.jsp");
			dispatcher.include(request, response);
			logger.debug("UpdatedSeats after booking:"+isUpdated);
			logger.info("Control is directed to passengers.jsp");
			}
			
		} catch(FMSException e) {
			logger.error("Error while adding the passengers", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doPost(request, response);
	}
}
