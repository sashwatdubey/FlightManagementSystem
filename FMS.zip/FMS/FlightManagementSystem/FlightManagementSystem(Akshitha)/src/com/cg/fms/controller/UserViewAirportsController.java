package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;
@WebServlet("/UserViewAirportsController")
public class UserViewAirportsController    extends HttpServlet { 
	static Logger logger = Logger.getLogger(UserViewAirportsController.class.getName());
	IAdminService service = new AdminService();
	RequestDispatcher dispatcher=null;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Airport> airports = new ArrayList<Airport>();
		HttpSession session = request.getSession();
		try {
			airports = service.viewAirports();
			logger.debug("List of Airports:"+airports);
			if(airports.size()>0) {
				dispatcher = request.getRequestDispatcher("viewAvailableFlights.jsp");
				request.setAttribute("airports", airports);
				dispatcher.forward(request, response);
				logger.info("Control is directed to ViewAvailableFlights.jsp");
				
			}
		} catch (FMSException e) {
			logger.error("Error while viewing the flights", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
		
		
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}

