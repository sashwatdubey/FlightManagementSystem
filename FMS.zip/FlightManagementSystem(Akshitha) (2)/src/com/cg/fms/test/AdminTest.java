package com.cg.fms.test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.cg.fms.dao.AdminDAO;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Flight;
import com.cg.fms.model.ScheduleFlight;

public class AdminTest {
	IAdminDAO adminDao = new AdminDAO();
	
	
	@Test
	public void addFlightTest() throws FMSException {
		
		Flight flight1 = new Flight("FMS110", "AirIndia", 450);
		int result1 = adminDao.addFlights(flight1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1, actualResult1);
				
	}
	
	@Test
	public void scheduleFlightTest() throws FMSException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		int flightNumber = 4;
		int availableSeats = 150;
		double cost = 4000;
		String sourceAirport = "Indira Gandhi International Airport(New Delhi)";
		String destinationAirport = "Pune Airport";
		Date departureDate = null;
		Date arrivalDate = null;
		try {
			departureDate = sdf.parse("2020/11/02");
			arrivalDate = sdf.parse("2020/11/02");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String arrivalTime = "12.30pm";
		String departureTime = "2.30pm";
		String flightStatus = "On Time";
		
		ScheduleFlight scheduleFlight = new ScheduleFlight(flightNumber, availableSeats, cost, sourceAirport, destinationAirport, departureDate, arrivalDate, arrivalTime, departureTime, flightStatus);
		int result1 = adminDao.scheduleFlight(scheduleFlight);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1, actualResult1);
				
	}
			
	@Test
	public void searchFlightTest() throws FMSException {
		
		boolean actualResult3 = false;
		List<ScheduleFlight> actualResult1 = adminDao.searchFlight(0);
		String expectedResult1 = "[]";
		assertEquals(expectedResult1, actualResult1.toString());
		
		List<ScheduleFlight> actualResult2 = adminDao.searchFlight(-1);
		String expectedResult2 = "[]";
		assertEquals(expectedResult2, actualResult2.toString());
		
		List<ScheduleFlight> result3 = adminDao.searchFlight(1);
		if(result3.size() > 0) {
			actualResult3 = true;
		} 
		boolean expectedResult3 = true;
		assertEquals(expectedResult3,actualResult3);
						
	}

}
