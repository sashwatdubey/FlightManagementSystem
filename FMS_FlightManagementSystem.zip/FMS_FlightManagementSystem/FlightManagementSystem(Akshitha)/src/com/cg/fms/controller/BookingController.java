package com.cg.fms.controller;

public class BookingController {

}
