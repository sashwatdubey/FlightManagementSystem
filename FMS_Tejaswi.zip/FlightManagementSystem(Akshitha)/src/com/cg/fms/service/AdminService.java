package com.cg.fms.service;


import java.util.List;
import com.cg.fms.dao.AdminDAO;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.model.Flight;
import com.cg.fms.model.ScheduleFlight;

public class AdminService implements IAdminService{

	IAdminDAO adminDao = new AdminDAO();
	
	@Override
	public int adminLogin(String emailId, String password) throws FMSException {
		
		return adminDao.adminLogin(emailId, password);
	}

	@Override
	public int addFlights(Flight flight) throws FMSException {
		
		return adminDao.addFlights(flight);
	}

	@Override
	public List<Flight> viewFlights() throws FMSException {
	
		return adminDao.viewFlights();
	}

	@Override
	public List<Airport> viewAirports() throws FMSException {
		
		return adminDao.viewAirports();
	}

	@Override
	public int scheduleFlight(ScheduleFlight scheduleFlight) throws FMSException {
	
		return adminDao.scheduleFlight(scheduleFlight);
	}
	
	public List<ScheduleFlight> viewScheduleFlights() throws FMSException {
		
		return adminDao.viewScheduleFlights();
	}
	
	public List<ScheduleFlight> searchFlight(int flightNumber) throws FMSException {
		
		return adminDao.searchFlight(flightNumber);
	}

	


}
