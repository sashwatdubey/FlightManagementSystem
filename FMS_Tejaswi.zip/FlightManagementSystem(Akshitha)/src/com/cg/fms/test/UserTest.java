package com.cg.fms.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cg.fms.dao.AdminDAO;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.dao.IUserDAO;
import com.cg.fms.dao.UserDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.model.User;

public class UserTest {
	
	IUserDAO userDao = new UserDAO();

	@Test
	public void isUserExistsTest() throws FMSException {
	    boolean actualResult1 = userDao.isUserExists("tejaswi.paridi@gmail.com");
		boolean expectedResult1 = true;
		assertEquals(expectedResult1, actualResult1);
		
		boolean actualResult2 = userDao.isUserExists("daniel.radcliff@gmail.com");
		boolean expectedResult2 = false;
		assertEquals(expectedResult2, actualResult2);
		
	}

	@Test
	public void accountCreationTest() throws FMSException {
		User user = new User("Sindhura", "5678", 9898989898l, "sindhura@gmail.com");
	    int isInserted = userDao.accountCreation(user);
	    boolean actualResult1;
	    boolean expectedResult1 = true;
	    if(isInserted > 0) 
	    	actualResult1 = true;
	    else
	    	actualResult1 = false;
		assertEquals(expectedResult1, actualResult1);
	}
	
	@Test
	public void userLoginTest() throws FMSException {
		
	    int rows1 = userDao.userLogin("tejaswi.paridi@gmail.com", "1234");
	    boolean actualResult1;
	    boolean expectedResult1 = true;
	    if(rows1 > 0) 
	    	actualResult1 = true;
	    else
	    	actualResult1 = false;
		assertEquals(expectedResult1, actualResult1);
		
		int rows2 = userDao.userLogin("tejaswi.paridi@gmail.com", "156234");
	    boolean actualResult2;
	    boolean expectedResult2 = false;
	    if(rows2 > 0) 
	    	actualResult2 = true;
	    else
	    	actualResult2 = false;
		assertEquals(expectedResult2, actualResult2);
		
	}
	
	
}
