package com.cg.fms.test;

import static org.junit.Assert.*;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.model.User;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

public class UserTest {
   IUserService userService = new UserService();
	@Test
	public void isUserExistsTest() throws FMSException{
		boolean actualResult1= userService.isUserExists("sindhu@gmail.com");
		boolean expectedResult1 =true;
		assertEquals(expectedResult1,actualResult1);
		
		
		boolean actualResult2= userService.isUserExists("sarah@gmail.com");
		boolean expectedResult2 =false;
		assertEquals(expectedResult2,actualResult2);
		
	}
	@Test
	public void accountCreationTest() throws FMSException {
		User user = new User("sindhu","sindhu",912345678,"sindhu@gmail.com");
		int result1= userService.accountCreation(user);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		User user1 = new User();
		int result2= userService.accountCreation(user1);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = false;
		} else {
			actualResult2 = true;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
				
	}
	
	@Test
	public void userLoginTest() throws FMSException {
		int result1= userService.userLogin("sindhu@gmail.com","sindhu");
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		
		int result2= userService.userLogin("sindhura@gmail.com","sindhura");
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
	}
	
	@Test
	public void makeBookingTest() throws FMSException {
	 Booking booking1 = new Booking(1,"2020/10/23",3400,2,"booked",1);
	 int result1= userService.makeBooking(booking1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1); 
	
	}
	
	
	@Test
	public void addPassengerTest() throws FMSException {
		Passengers passengers = new Passengers("sindhu",21,987651234,25.00,"F",1,"2020/10/23",20);
		int result1= userService.addPassengers(passengers);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
	}
	
	
	@Test
	public void viewBookings() throws FMSException {
		int userId1 = 1;
		int userId2 = 0;
		List<Booking> result1= userService.viewBookings(userId1);
		 boolean actualResult1;
			boolean expectedResult1;
			if(result1.size() !=0) {
				actualResult1 = true;
			} else {
				actualResult1 = false;
			}
			expectedResult1 = true;
			assertEquals(expectedResult1,actualResult1);
			
			
			
			List<Booking> result2= userService.viewBookings(userId2);
			boolean actualResult2;
			boolean expectedResult2;
			if( result2.size()!= 0) {
				actualResult2 = true;
			} else {
				actualResult2 = false;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2);
	}
	
	@Test
	public void cancelBookingTest() throws FMSException {
		boolean result1= userService.cancelBooking(34);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 == true) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		
		boolean result2= userService.cancelBooking(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 == false) {
			actualResult2 = false;
		} else {
			actualResult2 = true;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2); 
		
	}
	
	@Test
	public void deletePassengersTest() throws FMSException {
	
		boolean result1= userService.deletePassengers(24);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 == true) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		boolean result2= userService.deletePassengers(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 == false) {
			actualResult2 = false;
		} else {
			actualResult2 = true;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2); 
	
	
	}
	@Test
	public void modifyPassengersTest() throws FMSException {
		Passengers passenger1 = new Passengers(19,"Akshitha",29,45625864,21,"Female");
		 int result1= userService.modifyPassengers(passenger1);
		 boolean actualResult1;
		 boolean expectedResult1;
			if(result1 > 0) {
				actualResult1 = true;
			} else {
				actualResult1 = false;
			}
			expectedResult1 = true;
			assertEquals(expectedResult1,actualResult1);
			Passengers passenger2 = new Passengers();
			int result2= userService.modifyPassengers(passenger2);
			boolean actualResult2;
			boolean expectedResult2;
			if(result2 > 0) {
				actualResult2 = true;
			} else {
				actualResult2 = false;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2);
		
	}
	
	
	@Test
	public void viewBookingDetailsTest() throws FMSException {
		Booking result1= userService.viewBookingDetails(12);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 != null) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		
		Booking result2= userService.viewBookingDetails(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 != null) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
	
	}
	
	@Test
	public void viewPassengerDetailsTest() throws FMSException {
		
		 List<Passengers> result1= userService.viewPassengerDetails(12);
		 boolean actualResult1;
			boolean expectedResult1;
			if(result1.size() !=0) {
				actualResult1 = true;
			} else {
				actualResult1 = false;
			}
			expectedResult1 = true;
			assertEquals(expectedResult1,actualResult1);
			
			
			
			 List<Passengers> result2= userService.viewPassengerDetails(1);
			boolean actualResult2;
			boolean expectedResult2;
			if( result2.size()!= 0) {
				actualResult2 = false;
			} else {
				actualResult2 = true;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2);
		
	
	}
	@Test
	public void viewFlightDetailsTest() throws FMSException {
		ScheduleFlight result1=userService.viewFlightDetails(1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 != null) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		ScheduleFlight result2= userService.viewFlightDetails(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 == null) {
			actualResult2 = false;
		} else {
			actualResult2 = true;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2); 
		
	}
	
	@Test
	public void updateAvailableSeatsTest() throws FMSException {
		int result1= userService.updateAvailableSeats(50,1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		int result2= userService.updateAvailableSeats(100,0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
	}

}
