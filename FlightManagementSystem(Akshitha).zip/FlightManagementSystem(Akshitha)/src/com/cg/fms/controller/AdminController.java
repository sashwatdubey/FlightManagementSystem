package com.cg.fms.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		
		if(request.getParameter("addFlight") != null) {
			dispatcher = request.getRequestDispatcher("addFlight.jsp");
			dispatcher.include(request, response);
		} else if(request.getParameter("viewScheduledFlight") != null) {
			dispatcher = request.getRequestDispatcher("ViewScheduleFlightController");
			dispatcher.include(request, response);
		} else if(request.getParameter("viewFlights") != null) {
			dispatcher = request.getRequestDispatcher("ViewFlightsController");
			dispatcher.include(request, response);
		} else if(request.getParameter("searchFlight") != null){
			dispatcher = request.getRequestDispatcher("searchFlight.jsp");
			dispatcher.include(request, response);
		} else {
			dispatcher = request.getRequestDispatcher("cancelFlight.jsp");
			dispatcher.include(request, response);
		}
}
}
