package com.cg.fms.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	static Logger logger = Logger.getLogger(AdminController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		
		if(request.getParameter("addFlight") != null) {
			dispatcher = request.getRequestDispatcher("addFlight.jsp");
			dispatcher.include(request, response);
			logger.info("Control is directed to addFlight.jsp");
		} else if(request.getParameter("viewScheduledFlight") != null) {
			dispatcher = request.getRequestDispatcher("ViewScheduleFlightController");
			dispatcher.include(request, response);
			logger.info("Control is directed to ViewScheduleFlightController");
		} else if(request.getParameter("viewFlights") != null) {
			dispatcher = request.getRequestDispatcher("ViewFlightsController");
			dispatcher.include(request, response);
			logger.info("Control is directed to ViewFlightsController");
		} else if(request.getParameter("searchFlight") != null){
			dispatcher = request.getRequestDispatcher("searchFlight.jsp");
			dispatcher.include(request, response);
			logger.info("Control is directed to searchFlight.jsp");
		} else {
			dispatcher = request.getRequestDispatcher("cancelFlight.jsp");
			dispatcher.include(request, response);
			logger.info("Control is directed to cancelFlight.jsp");
			
		} 
}
}
