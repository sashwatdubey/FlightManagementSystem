package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fms.exceptions.FMSException;

import com.cg.fms.model.Passengers;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/BookingController")
public class BookingController  extends HttpServlet{
	
	static int passengerCount = 1;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IUserService service = new UserService();
	    PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		Passengers passenger = null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis()); 
		String bookingDate=timestamp.toString();  
		ServletContext context = request.getServletContext();
		int userId = Integer.parseInt(""+context.getAttribute("userId"));
		int bookingId = Integer.parseInt(""+context.getAttribute("bookingId"));
		int passengers = Integer.parseInt(""+context.getAttribute("passengerCount"));
		try {
				int addPassenger = 0;
				String passengerName = request.getParameter("name");
				int passengerAge = Integer.parseInt(request.getParameter("age"));
				String passengerGender = request.getParameter("gender");	
				double passengerLuggage = Double.parseDouble(request.getParameter("luggage"));
				long passengerAadhar = Long.parseLong(request.getParameter("aadhar"));
				passenger = new Passengers(passengerName,passengerAge,passengerAadhar,passengerLuggage,passengerGender,userId,bookingDate,bookingId);
				addPassenger = service.addPassengers(passenger);
				if(addPassenger > 0) {
					passengerCount++;
				}
				if(request.getParameter("addPassengers") != null && passengerCount <= passengers) {
				dispatcher = request.getRequestDispatcher("passengers.jsp");
				dispatcher.include(request, response);
				} else {
				out.println("successfully booked your flight");
				dispatcher = request.getRequestDispatcher("userPage.jsp");				
				dispatcher.forward(request, response);
				}
		} catch(FMSException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
