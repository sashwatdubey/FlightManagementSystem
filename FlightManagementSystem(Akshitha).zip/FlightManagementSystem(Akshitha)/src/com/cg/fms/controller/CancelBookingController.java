package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;

import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/CancelBookingController")
public class CancelBookingController  extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		IUserService service = new UserService();
		ScheduleFlight flight = null;
		int userId = 0;
		String bookingDate = null;
		boolean isDeleted = false;
		boolean isCancelled = false;
		int isUpdated = 0;
		int flightNumber = 0;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		int availableSeats = 0;
		int passengerCount = 0;
		try {
				Booking booking = service.viewBookingDetails(bookingId);
				userId = booking.getUserId();
				bookingDate = booking.getBookingDate();
				flightNumber = booking.getFlightNumber();
				passengerCount = booking.getPassengerCount();
				flight = service.viewFlightDetails(flightNumber);
				availableSeats = flight.getAvailableSeats();
				isCancelled = service.cancelBooking(bookingId);
				isDeleted = service.deletePassengers(bookingId);
				if(isCancelled && isDeleted) {
					availableSeats = flight.getAvailableSeats();
					availableSeats += (passengerCount);
					isUpdated = service.updateAvailableSeats(availableSeats, flightNumber);
					out.println("your booking has been cancelled successfully");
					dispatcher = request.getRequestDispatcher("userPage.jsp");
					dispatcher.forward(request, response);
					
				} else {
					out.println("problem occured while cancelling");
					dispatcher = request.getRequestDispatcher("userPage.jsp");
					dispatcher.forward(request, response);
				}
					
		} catch (FMSException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
