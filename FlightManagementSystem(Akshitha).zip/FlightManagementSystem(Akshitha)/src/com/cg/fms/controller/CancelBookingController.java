package com.cg.fms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/CancelBookingController")
public class CancelBookingController  extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
				IUserService service = new UserService();
				int userId = 0;
				String bookingDate = null;
				boolean isDeleted = false;
				boolean isCancelled = false;
				try {
					Booking booking = service.viewBookingDetails(5);
					userId = booking.getUserId();
					bookingDate = booking.getBookingDate();
					isDeleted = service.deletePassengers(bookingDate, userId);
					isCancelled = service.cancelBooking(5);
					Booking booking1 = service.viewBookingDetails(6);
					List<Passengers> passengers = service.viewPassengerDetails(booking1.getBookingDate(), booking1.getUserId());
					ScheduleFlight scheduleFlight = service.viewFlightDetails(booking1.getFlightNumber());
					System.out.println(booking1);
					System.out.println(passengers);
					System.out.println(scheduleFlight);
					
				} catch (FMSException e) {
					
					e.printStackTrace();
				}
	}

}
