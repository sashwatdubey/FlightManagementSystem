package com.cg.fms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Passengers;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/ViewPassengersController")
public class ViewPassengersController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IUserService service = new UserService();
		List<Passengers> passengers = null;
		RequestDispatcher dispatcher = null;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		try {
			passengers = service.viewPassengerDetails(bookingId);
			request.setAttribute("passengers", passengers);
			dispatcher = request.getRequestDispatcher("viewPassengerDetails.jsp");
			dispatcher.forward(request, response);
		}  catch (FMSException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
}
