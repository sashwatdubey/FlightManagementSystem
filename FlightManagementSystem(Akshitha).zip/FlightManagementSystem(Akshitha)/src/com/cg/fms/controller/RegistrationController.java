package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.User;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	IUserService service = new UserService();
	int isCreated = 0;
    PrintWriter out = response.getWriter();
	RequestDispatcher dispatcher = null;
	boolean isUserExists = false;
	String userName = request.getParameter("uname");
	String password = request.getParameter("upass");
	Long mobileNumber = Long.parseLong(request.getParameter("umobile"));
	String emailId = request.getParameter("uemail");
	
	try {
			User user = new User(userName, password, mobileNumber, emailId);
			isUserExists = service.isUserExists(emailId);
			if(isUserExists) {
				out.println("<script type=\"text/javascript\">");
				   out.println("alert('User already exists. Please login!');");
				   out.println("location='Login.jsp';");
				   out.println("</script>");
			} else {
				isCreated = service.accountCreation(user);
				if (isCreated > 0) {
					/*
					 * out.println("Account Created Successfully!!"); 
					  dispatcher =request.getRequestDispatcher("Login.jsp"); 
					  dispatcher.forward(request,response);
					 */ 
					out.println("<script type=\"text/javascript\">");
					   out.println("alert('Registered Successfully! Please login to continue.');");
					   out.println("location='Login.jsp';");
					   out.println("</script>");
					
				} else {
					/*
					 * out.println("Problem occured while inserting"); dispatcher =
					 * request.getRequestDispatcher("Register.jsp"); dispatcher.forward(request,
					 * response);
					 */
					
					out.println("<script type=\"text/javascript\">");
					   out.println("alert('Problem occured while registering. Please try again!');");
					   out.println("location='Register.jsp';");
					   out.println("</script>");
				}
			}
			
	} catch (FMSException e) {
		System.out.println(e.getMessage());
	}

	
}
}
