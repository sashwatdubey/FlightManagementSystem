package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/ViewBookingDetailsController")
public class ViewBookingDetailsController extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		IUserService service = new UserService();
		Booking booking = null;
		List<Passengers> passengers = null;
		ScheduleFlight scheduleFlight = null;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		try {
			booking = service.viewBookingDetails(bookingId);
			passengers = service.viewPassengerDetails(booking.getBookingDate(), booking.getUserId());
			scheduleFlight = service.viewFlightDetails(booking.getFlightNumber());
			if(booking != null && passengers.size() > 0 && scheduleFlight != null) {
				request.setAttribute("booking", booking);
				request.setAttribute("passengers", passengers);
				request.setAttribute("scheduleFlight", scheduleFlight);
				dispatcher = request.getRequestDispatcher("viewBookingDetails.jsp");
				dispatcher.forward(request, response);
				
			} else {
				out.println("problem occured while retrieving data");
				dispatcher = request.getRequestDispatcher("userPage.jsp");
				dispatcher.forward(request, response);
			}
		} catch (FMSException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
