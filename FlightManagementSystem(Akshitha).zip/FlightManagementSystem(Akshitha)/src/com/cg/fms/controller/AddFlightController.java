package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Flight;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;

@WebServlet("/AddFlightController")
public class AddFlightController extends HttpServlet {
	int isCreated =0;
	static Logger logger = Logger.getLogger(AddFlightController.class.getName());
	IAdminService service = new AdminService();
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
    String flightModel = request.getParameter("flightmodel");
	String carrierName = request.getParameter("carriername");
	int seatCapacity = Integer.parseInt(request.getParameter("seatcapacity"));
	Flight flight = new Flight(flightModel, carrierName, seatCapacity);
	PrintWriter out = response.getWriter();
	RequestDispatcher dispatcher =null;
	HttpSession session = request.getSession();
	if(flightModel == null & carrierName == null & seatCapacity == 0 ) {
		out.println("please enter correct values");
		dispatcher = request.getRequestDispatcher("addFlight.jsp");
		dispatcher.include(request, response);
		logger.info("while adding flights correct values are not entered or entered values are null");
		logger.info("Control is again directed to addFlight.jsp");
	
	} else {

	 try {
		isCreated = service.addFlights(flight);
		if(isCreated > 0) {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Flight added successfully');");
			out.println("location='addFlight.jsp';");
			out.println("</script>");
			logger.debug("isCreated Value :"+isCreated);
			logger.info("Flight is added successfully");
		} else {
			   out.println("<script type=\"text/javascript\">");
			   out.println("alert('Problem occured while adding. Please try again!');");
			   out.println("location='addFlight.jsp';");
			   out.println("</script>");
			   logger.info("Control Directed to addFlight.jsp if flights are not added");
		}
	 } catch (FMSException e) {
		 logger.error("Error while adding the flights", e);
		 session.setAttribute("errorMessage", e.getMessage());
		 response.sendRedirect("errorPage.jsp");
	}
		

	 }
	}
}
