package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	IUserService userService = new UserService();
	int isLogged =0;
	IAdminService adminService = new AdminService();
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws  IOException, ServletException {
	String emailId = request.getParameter("uemail");
	String password = request.getParameter("upass");
	PrintWriter out = response.getWriter();
	RequestDispatcher dispatcher =null;
	ServletContext context = request.getServletContext();
	try {
		if(emailId.equals("admin@fms.com") && password.equals("admin")) {
			isLogged = adminService.adminLogin(emailId, password);
			dispatcher = request.getRequestDispatcher("adminPage.jsp");
			dispatcher.forward(request, response);
		}
		else {
			isLogged = userService.userLogin(emailId,password);
		
		context.setAttribute("userId", isLogged);
		if(isLogged == 0) {
			if(userService.isUserExists(emailId)) {
				/*
				 * out.println("Please enter the correct password"); dispatcher =
				 * request.getRequestDispatcher("Login.jsp"); dispatcher.forward(request,
				 * response);
				 */
				out.println("<script type=\"text/javascript\">");
				   out.println("alert('Please enter the correct password!');");
				   out.println("location='Login.jsp';");
				   out.println("</script>");
			} else {
				/*
				 * out.println("user doesnot exists please register"); dispatcher =
				 * request.getRequestDispatcher("Register.jsp"); dispatcher.forward(request,
				 * response);
				 */
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('User doesnot exist. Please register!');");
				   out.println("location='Register.jsp';");
				   out.println("</script>");
			}
		} else {
			/*
			 * out.println("Logged in Successfully!!"); dispatcher =
			 * request.getRequestDispatcher("userPage.jsp"); dispatcher.forward(request,
			 * response);
			 */
			
			out.println("<script type=\"text/javascript\">");
			   out.println("alert('Logged in successfully');");
			   out.println("location='userPage.jsp';");
			   out.println("</script>");
			
		}
		}
			
	} catch (FMSException e) {
		request.setAttribute("message", e.toString());
		dispatcher = request.getRequestDispatcher("errorPage.jsp");
		dispatcher.forward(request, response);
	}		
	
}
}
