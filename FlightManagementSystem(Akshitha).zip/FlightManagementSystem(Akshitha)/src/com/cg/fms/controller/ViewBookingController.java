package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/ViewBookingController")
public class ViewBookingController  extends HttpServlet{

		@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			IUserService userService = new UserService();
			List<Booking> bookings = null;
			RequestDispatcher dispatcher = null;
			PrintWriter out = response.getWriter();
			ServletContext context = request.getServletContext();
			int userId = Integer.parseInt(""+context.getAttribute("userId"));
			try {
				bookings = userService.viewBookings(userId);
				if(bookings.size() > 0) {
					request.setAttribute("bookings",bookings);
					dispatcher = request.getRequestDispatcher("viewBookings.jsp");
					dispatcher.forward(request,response);
				} else {
					out.println("sorry bookings are not made yet");
					dispatcher = request.getRequestDispatcher("userPage.jsp");
					dispatcher.include(request,response);
					
				}
				
			} catch (FMSException e) {
				e.printStackTrace();
			}
			
			
			
			
		}
	
}
