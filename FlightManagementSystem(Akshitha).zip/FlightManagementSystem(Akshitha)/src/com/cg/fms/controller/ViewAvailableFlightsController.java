package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;

import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/ViewAvailableFlightsController")
public class ViewAvailableFlightsController  extends HttpServlet{
	IUserService userService = new UserService();
	RequestDispatcher dispatcher=null;
	static Logger logger = Logger.getLogger(ViewAvailableFlightsController.class.getName());
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		HttpSession session = request.getSession();
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String departure = request.getParameter("departureDate");
		List<ScheduleFlight> scheduleFlights = null;
		Date departureDate;
		try {
			departureDate = new SimpleDateFormat("yyyy-MM-dd").parse(departure);
			scheduleFlights = userService.viewAvailableFlights(source,destination,departureDate);
			if(scheduleFlights.size() > 0) {
				request.setAttribute("scheduleFlights",scheduleFlights);
				dispatcher = request.getRequestDispatcher("displayAvailableFlights.jsp");
				dispatcher.forward(request,response);
				logger.info("Control is directed to displayAvailableFlights.jsp to view all the flights");
			} else {
				logger.info("Flights are not added yet" );
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Sorry, we are not serving this route!');");
				out.println("location='userPage.jsp';");
				out.println("</script>");
				
			}
			
			
		} catch (ParseException e) {
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		} catch(FMSException e) {
			logger.error("Error while viewing the flights", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
		
	}
}
 
	
		


