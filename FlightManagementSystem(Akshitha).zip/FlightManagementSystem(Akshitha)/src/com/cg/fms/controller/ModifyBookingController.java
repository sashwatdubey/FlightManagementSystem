package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Passengers;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

@WebServlet("/ModifyBookingController")
public class ModifyBookingController extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IUserService service = new UserService();
	    PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		Passengers passenger = null;
		HttpSession session = request.getSession();
		String passengerName = request.getParameter("name");
		int passengerAge = Integer.parseInt(request.getParameter("age"));
		String passengerGender = request.getParameter("gender");	
		double passengerLuggage = Double.parseDouble(request.getParameter("luggage"));
		long passengerAadhar = Long.parseLong(request.getParameter("aadhar"));
		int pnrNumber = (int)session.getAttribute("pnrNumber");
		int isModified = 0;
		try { 
			passenger = new Passengers(pnrNumber, passengerName,passengerAge,passengerAadhar,passengerLuggage,passengerGender);
			isModified = service.modifyPassengers(passenger);
			if(isModified > 0) {
				out.println("successfully modified your details");
				dispatcher = request.getRequestDispatcher("userPage.jsp");				
				dispatcher.forward(request, response);
			} else {
				out.println("Failed to modify the details");
				dispatcher = request.getRequestDispatcher("userPage.jsp");				
				dispatcher.forward(request, response);
			}
		} catch(FMSException e) {
			e.printStackTrace();
		}
		
	}

}
