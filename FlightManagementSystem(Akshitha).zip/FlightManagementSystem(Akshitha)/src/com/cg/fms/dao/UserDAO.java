package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.model.User;
import com.cg.fms.utility.JdbcUtility;

public class UserDAO implements IUserDAO{

	static Connection connection = null;
	static PreparedStatement prepareStatement = null;
	static ResultSet resultSet = null;
	
	/*Method to check whether the entered user exists or not*/
	public boolean isUserExists(String emailId) throws FMSException {
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.USER_EXISTS);
			prepareStatement.setString(1, emailId);
			resultSet = prepareStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
			}
		} catch (SQLException e) {
			throw new FMSException("problem while creating PS object");
		} catch (ClassNotFoundException e) {
			throw new FMSException("problem while creating PS object");
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
        return found;
	}
	
	/*Method for the user to create his account*/
	public int accountCreation(User user) throws FMSException {
		
				int isInserted = 0;
				try {
				  connection = JdbcUtility.getConnection();
				  prepareStatement = connection.prepareStatement(CustomerQueryConstants.REGISTER_USER, Statement.RETURN_GENERATED_KEYS );
				  prepareStatement.setString(1,user.getUserName());
				  prepareStatement.setString(2,user.getPassword() );
				  prepareStatement.setLong(3,user.getMobileNumber() );
				  prepareStatement.setString(4,user.getEmailId() );
				  prepareStatement.executeUpdate();
				  resultSet = prepareStatement.getGeneratedKeys();
				while(resultSet.next()) {
					isInserted = resultSet.getInt(1);
				}
				} catch (SQLException | ClassNotFoundException e) {
					e.printStackTrace();
				} finally {
					try {
						connection.close();
					} catch (SQLException e) {
						throw new FMSException("problem while closing");
					}

				}
				return isInserted;
	}
	
	/*Method for user to login into the application*/
	public int userLogin(String emailId, String password) throws FMSException {
		
		int rows =0;
		try {
				connection = JdbcUtility.getConnection();
				prepareStatement = connection.prepareStatement(CustomerQueryConstants.USER_LOGIN);
				prepareStatement.setString(1, emailId);
				prepareStatement.setString(2, password);
				resultSet = prepareStatement.executeQuery();
				if(resultSet.next()) {
					rows = resultSet.getInt(1);
					
				}
			}
			catch(ClassNotFoundException e) {
				System.out.println(e.getMessage());
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException e) {
					throw new FMSException("problem while closing");
				}

			}
			return rows;
	}
	
	/*Method to enter all passenger details*/
	public int addPassengers(Passengers passenger) throws FMSException {
		int isInserted = 0;
		try {
		  connection = JdbcUtility.getConnection();
		  prepareStatement = connection.prepareStatement(CustomerQueryConstants.ADD_PASSENGER, Statement.RETURN_GENERATED_KEYS );
		  prepareStatement.setString(1,passenger.getPassengerName());
		  prepareStatement.setInt(2,passenger.getPassengerAge() );
		  prepareStatement.setLong(3,passenger.getPassengerUIN() );
		  prepareStatement.setDouble(4,passenger.getLuggage());
		  prepareStatement.setInt(5,passenger.getUserId() );
		  prepareStatement.setString(6,passenger.getPassengerGender());
		  prepareStatement.setString(7, passenger.getBookingDate());
		  prepareStatement.executeUpdate();
		  resultSet = prepareStatement.getGeneratedKeys();
		while(resultSet.next()) {
			isInserted = resultSet.getInt(1);
		}
		  System.out.println("inserted successfully");
		} catch (SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return isInserted;
	}
	
	/*Method to delete passengers details if passengers cancels their booking*/
	public boolean deletePassengers(String bookingDate, int userId) throws FMSException {
		boolean isDeleted = false;
		int rowUpdate = 0;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.DELETE_PASSENGERS);
			prepareStatement.setInt(1, userId);
			prepareStatement.setString(2, bookingDate);
			rowUpdate = prepareStatement.executeUpdate();
			if(rowUpdate > 0) {
				isDeleted = true;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}	
		return isDeleted;
	}
	
	/*Method to book a flight*/
	public int makeBooking(Booking booking) throws FMSException {
		int isInserted = 0;
		try {
		  connection = JdbcUtility.getConnection();
		  prepareStatement = connection.prepareStatement(CustomerQueryConstants.MAKE_BOOKING, Statement.RETURN_GENERATED_KEYS );
		  prepareStatement.setInt(1,booking.getUserId());
		  prepareStatement.setString(2,booking.getBookingDate() );
		  prepareStatement.setDouble(3,booking.getCost());
		  prepareStatement.setDouble(4,booking.getPassengerCount());
		  prepareStatement.setString(5,booking.getBookingState() );
		  prepareStatement.setInt(6,booking.getFlightNumber());
		  prepareStatement.executeUpdate();
		  resultSet = prepareStatement.getGeneratedKeys();
		while(resultSet.next()) {
			isInserted = resultSet.getInt(1);
		}
		  System.out.println("inserted successfully");
		} catch (SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return isInserted;
	}
	
	/*Method to cancel booking made by customer*/
	public boolean cancelBooking(int bookingId) throws FMSException {
		boolean isCancelled = false;
		int rowUpdate = 0;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.CANCEL_BOOKING);
			prepareStatement.setInt(1, bookingId);
			rowUpdate= prepareStatement.executeUpdate();
			if(rowUpdate>0) {
				isCancelled = true;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}	
		return isCancelled;
	}

	/*Method to view all the bookings made by the customer*/
	public List<Booking> viewBookings(int userId) throws FMSException {
		List<Booking> bookings = new ArrayList<Booking>();
		Booking booking  = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.VIEW_BOOKINGS);
			prepareStatement.setInt(1, userId);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				booking= new Booking();
				booking.setBookingId(resultSet.getInt(1));
				booking.setUserId(resultSet.getInt(2));
				booking.setBookingDate(resultSet.getString(3));
				booking.setCost(resultSet.getDouble(4));
				booking.setPassengerCount(resultSet.getInt(5));
				booking.setBookingState(resultSet.getString(6));
				booking.setFlightNumber(resultSet.getInt(7));
				bookings.add(booking);
			}
		
		} catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return bookings;
	}
	
	/*Method to view all the available flights*/
	public List<ScheduleFlight> viewAvailableFlights(String source, String destination) throws FMSException {
		List<ScheduleFlight> scheduleFlights = new ArrayList<ScheduleFlight>();
		ScheduleFlight scheduleFlight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.VIEW_AVAILABLE_FLIGHTS);
			prepareStatement.setString(1, source);
			prepareStatement.setString(2, destination);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				scheduleFlights.add(scheduleFlight);
			}
		
		} catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return scheduleFlights;
	}
	
	/*Method to change or update passenger details after booking*/
	public int modifyPassengers(List<Passengers> passenger) throws FMSException {
		int isModify = 0;
		for(Passengers passengers: passenger ) {
			try {
				connection = JdbcUtility.getConnection();
				prepareStatement = connection.prepareStatement(CustomerQueryConstants.UPDATE_PASSENGER);
				prepareStatement.setString(1, passengers.getPassengerName());
				prepareStatement.setInt(2, passengers.getPassengerAge());
				prepareStatement.setLong(3, passengers.getPassengerUIN());
				prepareStatement.setDouble(4, passengers.getLuggage());
				prepareStatement.setString(5, passengers.getPassengerGender());
				prepareStatement.setInt(6, passengers.getUserId());
				prepareStatement.setString(7, passengers.getBookingDate());
				prepareStatement.setInt(8, passengers.getPnrNumber());
				isModify = prepareStatement.executeUpdate();
				
			}
			catch(SQLException e) {
				e.printStackTrace();
			} catch(ClassNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					connection.close();
				} catch (SQLException e) {
					throw new FMSException("problem while closing");
				}
				
			}	
		
			
		}
		return isModify;
	}
	
	/*Method to view all booking details after booking is done*/
	public Booking viewBookingDetails(int bookingId) throws FMSException {
		Booking booking  = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.VIEW_BOOKING_DETAILS);
			prepareStatement.setInt(1, bookingId);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				booking= new Booking();
				booking.setBookingId(resultSet.getInt(1));
				booking.setUserId(resultSet.getInt(2));
				booking.setBookingDate(resultSet.getString(3));
				booking.setCost(resultSet.getDouble(4));
				booking.setPassengerCount(resultSet.getInt(5));
				booking.setBookingState(resultSet.getString(6));
				booking.setFlightNumber(resultSet.getInt(7));
			
				
			}
		
		} catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return booking;
	}
	
	/*Method to view all passenger details based on booking*/
	public List<Passengers> viewPassengerDetails(String bookingDate, int userId) throws FMSException {
		List<Passengers> passengers = new ArrayList<Passengers>();
		Passengers passenger  = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.VIEW_PASSENGER_DETAILS);
			prepareStatement.setString(1,bookingDate);
			prepareStatement.setInt(2, userId);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				passenger= new Passengers();
				passenger.setPnrNumber(resultSet.getInt(1));
				passenger.setPassengerName(resultSet.getString(2));
				passenger.setPassengerAge(resultSet.getInt(3));
				passenger.setPassengerUIN(resultSet.getLong(4));
				passenger.setLuggage(resultSet.getDouble(5));
				passenger.setUserId(resultSet.getInt(6));
				passenger.setPassengerGender(resultSet.getString(7));
				passenger.setBookingDate(resultSet.getString(8));
			
				passengers.add(passenger);
			}
		
		} catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return passengers;
	}
	
	/*Method to view flight details booked by the customer*/
	public ScheduleFlight viewFlightDetails(int flightNumber) throws FMSException {
		ScheduleFlight scheduleFlight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.VIEW_FLIGHT_DETAILS);
			prepareStatement.setInt(1, flightNumber);
			resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				
			}
		
		} catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return scheduleFlight;
	}

	/*Method to update available seats based on booking made*/
	public int updateAvailableSeats(int availableSeats, int flightNumber) throws FMSException {
		int isUpdated = 0;
		try {
			connection = JdbcUtility.getConnection();
			prepareStatement = connection.prepareStatement(CustomerQueryConstants.UPDATE_AVAILABLE_SEATS);
			prepareStatement.setInt(1, availableSeats);
			prepareStatement.setInt(2, flightNumber);
			isUpdated =prepareStatement.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new FMSException("problem while closing");
			}

		}
		return isUpdated;
	}
		
	
	
	

	
}
