package com.cg.fms.service;


import java.util.Date;
import java.util.List;
import com.cg.fms.dao.AdminDAO;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.model.Flight;
import com.cg.fms.model.ScheduleFlight;

public class AdminService implements IAdminService{

	IAdminDAO adminDao = new AdminDAO();
	
	/************************************************
	 @Description: Method to add flights
	 @Author: Paruchuri Sindhura
	 @arg1: Flight flight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int addFlights(Flight flight) throws FMSException {
		return adminDao.addFlights(flight);
	}
	
	/************************************************
	 @Description: Method to view flights
	 @Author: Tejaswi Paridi
	 @returns: List flight
	 @Exception: FMSException
	 ************************************************/
	public List<Flight> viewFlights() throws FMSException {
		return adminDao.viewFlights();
	}
	
	/************************************************
	 @Description: Method to view all airports
	 @Author: Paruchuri Sindhura, Tejaswi Paridi
	 @returns: List airports
	 @Exception: FMSException
	 ************************************************/
	public List<Airport> viewAirports() throws FMSException {
		return adminDao.viewAirports();
	}

	/************************************************
	 @Description: Method to schedule flights
	 @Author: Paruchuri Sindhura
	 @arg1: ScheduleFlight scheduleFlight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int scheduleFlight(ScheduleFlight scheduleFlight) throws FMSException {
		return adminDao.scheduleFlight(scheduleFlight);
	}
	
	/********************************************************
	 @Description: Method to search flights by flight number
	 @Author: Tejaswi Paridi
	 @arg1: int flightNumber
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 ********************************************************/
	public List<ScheduleFlight> searchFlight(int flightNumber) throws FMSException {
		return adminDao.searchFlight(flightNumber);
	}
	
	/*****************************************************
	 @Description: method to view all the scheduled flights
	 @Author: Paruchuri Sindhura, Tejaswi Paridi
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 *****************************************************/
	public List<ScheduleFlight> viewScheduleFlights() throws FMSException {
		return adminDao.viewScheduleFlights();
	}
	

	/************************************************
	 @Description: Admin Login
	 @Author: Bhavana Teja
	 @arg1: String emailId
	 @arg2: String password
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int adminLogin(String emailId, String password) throws FMSException {
		return adminDao.adminLogin(emailId, password);
	}

	/************************************************************
	 @Description: Method to check if flight is already scheduled
	 @Author: Paruchuri Sindhura
	 @arg1: int flightNumber
	 @arg2: java.util.Date arrivalDate
	 @arg3: java.util.Date departureDate
	 @returns: boolean
	 @Exception: FMSException
	 *************************************************************/
	public boolean isFlightExists(int flightNumber, Date arrivalDate, Date departureDate) throws FMSException {
		return adminDao.isFlightExists(flightNumber, arrivalDate, departureDate);
	}
	
	/************************************************************
	 @Description: Method to get flight details
	 @Author: Paruchuri Sindhura
	 @arg1: String flightModel
	 @returns: int
	 @Exception: FMSException
	 *************************************************************/
	public int getFlightNumber(String flightModel) throws FMSException {
		return adminDao.getFlightDetails(flightModel);
	}
	
	

}
