package com.cg.fms.service;

import java.util.Date;
import java.util.List;

import com.cg.fms.dao.IUserDAO;
import com.cg.fms.dao.UserDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.model.User;

public class UserService implements IUserService {

	IUserDAO userDao = new UserDAO();
	
	/*********************************************************************
	 @Description : Method to check whether the entered user exists or not
	 @author : Bhavana Teja
	 @arg1 : String emailId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean isUserExists(String emailId) throws FMSException {
		return userDao.isUserExists(emailId);
	}


	/*********************************************************************
	 @Description : Method for the user to create his account
	 @author : Bhavana Teja
	 @arg1 : User user
	 @return : int
	 @Exception : FMSException
	 */
	public int accountCreation(User user) throws FMSException {
		return userDao.accountCreation(user);
	}

	/*********************************************************************
	 @Description : Method for user to login into the application
	 @author : Bhavana Teja
	 @arg1 : String emailId
	 @arg2 : String password
	 @return : int 
	 @Exception : FMSException
	 */
	public int userLogin(String emailId, String password) throws FMSException {
		return userDao.userLogin(emailId, password);
	}
	/*********************************************************************
	 @Description : Method to enter all passenger details
	 @author : Sashwat Dubey
	 @arg1 : Passengers passenger
	 @return : int
	 @Exception : FMSException
	 */
	public int addPassengers(Passengers passenger) throws FMSException {
		return userDao.addPassengers(passenger);
	}
	
	/*********************************************************************
	 @Description : 
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean deletePassengers(int bookingId) throws FMSException {
		return userDao.deletePassengers(bookingId);
	}

	/*********************************************************************
	 @Description : Method to book a flight
	 @author : Sashwat Dubey
	 @arg1 : Booking booking
	 @return : int
	 @Exception : FMSException
	 */

	public int makeBooking(Booking booking) throws FMSException {
		return userDao.makeBooking(booking);
	}

	/*********************************************************************
	 @Description : Method to cancel booking made by customer
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean cancelBooking(int bookingId) throws FMSException {
		return userDao.cancelBooking(bookingId);
	}
	
	/*********************************************************************
	 @Description : Method to view all the bookings made by the customer
	 @author : Akshitha Gampa
	 @arg1 : int userId
	 @return : List<Booking>
	 @Exception : FMSException
	 */
	public List<Booking> viewBookings(int userId) throws FMSException {
		return userDao.viewBookings(userId);
	}


	/*********************************************************************
	 @Description : 
	 @author : Sashwat Dubey
	 @arg1 : String source
	 @arg2 : String destination
	 @arg3 : java.util.Date departureDate
	 @return : List<ScheduleFlight> 
	 @Exception : FMSException
	 */
	public List<ScheduleFlight> viewAvailableFlights(String source,String destination, Date departureDate) throws FMSException {
		return userDao.viewAvailableFlights(source, destination, departureDate);
	}
	
	/*********************************************************************
	 @Description : Method to change or update passenger details after booking
	 @author : Akshitha Gampa
	 @arg1 : Passengers passengers
	 @return : int
	 @Exception : FMSException
	 */
	public int modifyPassengers(Passengers passenger) throws FMSException {
		return userDao.modifyPassengers(passenger);
	}
	
	/*********************************************************************
	 @Description : Method to view all booking details after booking is done
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : Booking
	 @Exception :  FMSException 
	 */
	public Booking viewBookingDetails(int bookingId) throws FMSException {
		return userDao.viewBookingDetails(bookingId);
	}

	/*********************************************************************
	 @Description : Method to view all passenger details based on booking
	 @author : Akshitha Gampa
	 @arg1 : int bookingId
	 @return : List<Passengers>
	 @Exception : FMSException
	 */
	public List<Passengers> viewPassengerDetails(int bookingId) throws FMSException {
		return userDao.viewPassengerDetails(bookingId);
	}
	

	/*********************************************************************
	 @Description : Method to view flight details booked by the customer
	 @author : Akshitha Gampa
	 @arg1 : int flightNumber
	 @return : ScheduleFlight
	 @Exception : int flightNumber
	 */
	public ScheduleFlight viewFlightDetails(int flightNumber) throws FMSException {
		return userDao.viewFlightDetails(flightNumber);
	}

	/*********************************************************************
	 @Description : Method to update available seats based on booking made
	 @author : Akshitha Gampa
	 @arg1 : int availableSeats
	 @arg2: int flightNumber
	 @return : int
	 @Exception : FMSException
	 */
	public int updateAvailableSeats(int availableSeats, int flightNumber) throws FMSException {
		return userDao.updateAvailableSeats(availableSeats, flightNumber);
	}
	

}
