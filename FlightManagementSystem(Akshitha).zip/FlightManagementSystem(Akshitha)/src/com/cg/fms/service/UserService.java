package com.cg.fms.service;

import java.util.Date;
import java.util.List;

import com.cg.fms.dao.IUserDAO;
import com.cg.fms.dao.UserDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;
import com.cg.fms.model.Passengers;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.model.User;

public class UserService implements IUserService {

	IUserDAO userDao = new UserDAO();

	public boolean isUserExists(String emailId) throws FMSException {
		return userDao.isUserExists(emailId);
	}

	public int accountCreation(User user) throws FMSException {
		return userDao.accountCreation(user);
	}

	public int userLogin(String emailId, String password) throws FMSException {
		return userDao.userLogin(emailId, password);
	}

	public int addPassengers(Passengers passenger) throws FMSException {
		return userDao.addPassengers(passenger);
	}
	
	public boolean deletePassengers(int bookingId) throws FMSException {
		return userDao.deletePassengers(bookingId);
	}

	public int makeBooking(Booking booking) throws FMSException {
		return userDao.makeBooking(booking);
	}

	public boolean cancelBooking(int bookingId) throws FMSException {
		return userDao.cancelBooking(bookingId);
	}

	public List<Booking> viewBookings(int userId) throws FMSException {
		return userDao.viewBookings(userId);
	}

	public List<ScheduleFlight> viewAvailableFlights(String source,String destination, Date departureDate) throws FMSException {
		return userDao.viewAvailableFlights(source, destination, departureDate);
	}
	
	public int modifyPassengers(Passengers passenger) throws FMSException {
		return userDao.modifyPassengers(passenger);
	}
	
	public Booking viewBookingDetails(int bookingId) throws FMSException {
		return userDao.viewBookingDetails(bookingId);
	}

	public List<Passengers> viewPassengerDetails(int bookingId) throws FMSException {
		return userDao.viewPassengerDetails(bookingId);
	}
	
	public ScheduleFlight viewFlightDetails(int flightNumber) throws FMSException {
		return userDao.viewFlightDetails(flightNumber);
	}

	public int updateAvailableSeats(int availableSeats, int flightNumber) throws FMSException {
		return userDao.updateAvailableSeats(availableSeats, flightNumber);
	}
	

}
