package com.cg.fms.service;

import java.util.Date;
import java.util.List;

import com.cg.fms.dao.IScheduleFlightDAO;
import com.cg.fms.dao.ScheduleFlightDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;

public class ScheduleFlightService implements IScheduleFlightService{
	
	IScheduleFlightDAO scheduleFlightDao = new ScheduleFlightDAO();
	/************************************************
	 @Description: Method to schedule flights
	 @Author: Paruchuri Sindhura
	 @arg1: ScheduleFlight scheduleFlight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int scheduleFlight(ScheduleFlight scheduleFlight) throws FMSException {
		return scheduleFlightDao.scheduleFlight(scheduleFlight);
	}
	
	/********************************************************
	 @Description: Method to search flights by flight number
	 @Author: Tejaswi Paridi
	 @arg1: int flightNumber
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 ********************************************************/
	public List<ScheduleFlight> searchFlight(int flightNumber) throws FMSException {
		return scheduleFlightDao.searchFlight(flightNumber);
	}
	
	/*****************************************************
	 @Description: method to view all the scheduled flights
	 @Author: Paruchuri Sindhura, Tejaswi Paridi
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 *****************************************************/
	public List<ScheduleFlight> viewScheduleFlights() throws FMSException {
		return scheduleFlightDao.viewScheduleFlights();
	}
	

	/************************************************************
	 @Description: Method to check if flight is already scheduled
	 @Author: Paruchuri Sindhura
	 @arg1: int flightNumber
	 @arg2: java.util.Date arrivalDate
	 @arg3: java.util.Date departureDate
	 @returns: boolean
	 @Exception: FMSException
	 *************************************************************/
	public boolean isFlightScheduled(int flightNumber, Date arrivalDate, Date departureDate) throws FMSException {
		return scheduleFlightDao.isFlightScheduled(flightNumber, arrivalDate, departureDate);
	}
	
	
	/*********************************************************************
	 @Description : 
	 @author : Sashwat Dubey
	 @arg1 : String source
	 @arg2 : String destination
	 @arg3 : java.util.Date departureDate
	 @return : List<ScheduleFlight> 
	 @Exception : FMSException
	 */
	public List<ScheduleFlight> viewAvailableFlights(String source,String destination, Date departureDate) throws FMSException {
		return scheduleFlightDao.viewAvailableFlights(source, destination, departureDate);
	}
	
	/*********************************************************************
	 @Description : Method to view flight details booked by the customer
	 @author : Akshitha Gampa
	 @arg1 : int flightNumber
	 @return : ScheduleFlight
	 @Exception : int flightNumber
	 */
	public ScheduleFlight viewFlightDetails(int flightNumber) throws FMSException {
		return scheduleFlightDao.viewFlightDetails(flightNumber);
	}
	
	/*********************************************************************
	 @Description : Method to update available seats based on booking made
	 @author : Akshitha Gampa
	 @arg1 : int availableSeats
	 @arg2: int flightNumber
	 @return : int
	 @Exception : FMSException
	 */
	public int updateAvailableSeats(int availableSeats, int flightNumber) throws FMSException {
		return scheduleFlightDao.updateAvailableSeats(availableSeats, flightNumber);
	}

}
