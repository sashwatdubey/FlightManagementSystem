package com.cg.fms.service;

import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;

public interface IBookingService {

	public List<Booking> viewBookings(int userId) throws FMSException;
	
	public int makeBooking(Booking booking) throws FMSException;
	
	public boolean cancelBooking(int bookingId) throws FMSException;

	public Booking viewBookingDetails(int bookingId) throws FMSException;
	
}
