package com.cg.fms.service;


import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Flight;


public interface IFlightService {

	public int addFlights(Flight flight) throws FMSException;
	
	public List<Flight> viewFlights() throws FMSException;
	
	public int getFlightNumber(String flightModel) throws FMSException;
	
	
}
