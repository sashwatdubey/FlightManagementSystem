package com.cg.fms.service;

import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Passengers;

public interface IPassengerService {

	public int addPassengers(Passengers passenger) throws FMSException;
	
	public boolean deletePassengers(int bookingId) throws FMSException;
	
	public int modifyPassengers(Passengers passenger) throws FMSException;
	
	public List<Passengers> viewPassengerDetails(int bookingId) throws FMSException;
}
