package com.cg.fms.service;

import java.util.Date;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;

public interface IScheduleFlightService {

	public boolean isFlightScheduled(int flightNumber, Date arrivalDate, Date departureDate) throws FMSException;
	
	public int scheduleFlight(ScheduleFlight scheduleFlight) throws FMSException;
	
	public List<ScheduleFlight> searchFlight(int flightNumber) throws FMSException;
	
	public List<ScheduleFlight> viewScheduleFlights() throws FMSException;
	
	public ScheduleFlight viewFlightDetails(int flightNumber) throws FMSException;
	
	public int updateAvailableSeats(int availableSeats, int flightNumber) throws FMSException;

	public List<ScheduleFlight> viewAvailableFlights(String source, String destination, Date departureDate) throws FMSException;
}
