package com.cg.fms.service;

import java.util.List;
import com.cg.fms.dao.FlightDAO;
import com.cg.fms.dao.IFlightDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Flight;

public class FlightService implements IFlightService{
	
	IFlightDAO flightDao = new FlightDAO();
	/************************************************
	 @Description: Method to add flights
	 @Author: Paruchuri Sindhura
	 @arg1: Flight flight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int addFlights(Flight flight) throws FMSException {
		return flightDao.addFlights(flight);
	}
	
	/************************************************
	 @Description: Method to view flights
	 @Author: Tejaswi Paridi
	 @returns: List flight
	 @Exception: FMSException
	 ************************************************/
	public List<Flight> viewFlights() throws FMSException {
		return flightDao.viewFlights();
	}
	
	/************************************************************
	 @Description: Method to get flight details
	 @Author: Paruchuri Sindhura
	 @arg1: String flightModel
	 @returns: int
	 @Exception: FMSException
	 *************************************************************/
	public int getFlightNumber(String flightModel) throws FMSException {
		return flightDao.getFlightDetails(flightModel);
	}
	


}
