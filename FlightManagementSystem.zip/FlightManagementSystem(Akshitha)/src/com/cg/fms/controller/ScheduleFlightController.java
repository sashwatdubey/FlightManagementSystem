package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;

@WebServlet("/ScheduleFlightController")
public class ScheduleFlightController extends HttpServlet {
	static Logger logger = Logger.getLogger(ScheduleFlightController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		ServletContext context = request.getServletContext();
		IAdminService service = new AdminService();
		int flightNumber = Integer.parseInt(""+context.getAttribute("flightNumber"));
		double ticketCost = Double.parseDouble(request.getParameter("cost"));
		int availableSeats = Integer.parseInt(request.getParameter("availableSeats"));
		String sourceAirport = request.getParameter("source");
		String destinationAirport = request.getParameter("destination");
		String arrivalTime = request.getParameter("arrivalTime");
		String departureTime = request.getParameter("departureTime");
		String flightStatus = request.getParameter("flightstatus");
		int isCreated = 0;
		boolean isFlightExists = false;
		if(sourceAirport.equals(destinationAirport)) {
			   out.println("<script type=\"text/javascript\">");
			   out.println("alert('Source and Destination can't be the same. Please try again!');");
			   out.println("location='adminPage.jsp';");
			   out.println("</script>");
		
		} else {

		 try {
			Date departureDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("departureDate"));
			Date arrivalDate= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("arrivalDate"));
			isFlightExists = service.isFlightScheduled(flightNumber, arrivalDate, departureDate);
			if(isFlightExists) {
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Flight is already scheduled!');");
				   out.println("location='adminPage.jsp';");
				   out.println("</script>");
				   logger.info("Flight is already scheduled in ScheduleFlightController");
			} else {
				ScheduleFlight scheduleFlight = new ScheduleFlight(flightNumber, availableSeats, ticketCost, sourceAirport, destinationAirport, departureDate, arrivalDate, arrivalTime, departureTime, flightStatus);		
				isCreated = service.scheduleFlight(scheduleFlight);
				logger.debug("Value of isCreated in ScheduleFlightController:"+isCreated);
				if(isCreated > 0) {
					   out.println("<script type=\"text/javascript\">");
					   out.println("alert('Successfully scheduled!');");
					   out.println("location='adminPage.jsp';");
					   out.println("</script>");
					   logger.info("Flight is scheduled");
					   logger.info("Control is directed to ViewFlightsController");
				} else {
					   out.println("<script type=\"text/javascript\">");
					   out.println("alert('Problem occured while scheduling. Please try again!');");
					   out.println("location='adminPage.jsp';");
					   out.println("</script>");
					   logger.info("Problem occurred while inserting values in ScheduleFlightController");
				}
			}
		 } catch (FMSException | ParseException e) {
			 logger.error("Error while adding the flights", e);
			 session.setAttribute("errorMessage", e.getMessage());
			 response.sendRedirect("errorPage.jsp");
		}
			

		 }
		
		
		
	}
}
