package com.cg.fms.test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.cg.fms.dao.AdminDAO;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.model.Flight;
import com.cg.fms.model.ScheduleFlight;

public class AdminTest {
	IAdminDAO adminDao = new AdminDAO();
	
	@Test
	public void adminLoginTest() throws FMSException {
		int result1= adminDao.adminLogin("admin@gmail.com","Admin24!");
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
		actualResult1 = true;
		} else {
		actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		int result2= adminDao.adminLogin("admin@gmail.com","admin");
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
		actualResult2 = true;
		} else {
		actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
		int result3= adminDao.adminLogin("sindhura@gmail.com","Admin@123");
		boolean actualResult3;
		boolean expectedResult3;
		if(result3 > 0) {
		actualResult3 = true;
		} else {
		actualResult3 = false;
		}
		expectedResult3 = false;
		assertEquals(expectedResult3,actualResult3);
		
		int result4= adminDao.adminLogin("sindhura@gmail.com","Sindhu@123");
		boolean actualResult4;
		boolean expectedResult4;
		if(result4 > 0) {
		actualResult4 = true;
		} else {
		actualResult4 = false;
		}
		expectedResult4 = false;
		assertEquals(expectedResult4,actualResult4);
		
		
	}
	
	@Test
	public void addFlightTest() throws FMSException {
	
	Flight flight1 = new Flight("AirBusA110", "AirIndia", 450);
	int result1 = adminDao.addFlights(flight1);
	boolean actualResult1;
	boolean expectedResult1;
	if(result1 > 0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1, actualResult1);
	
	Flight flight2 = null;
	int result2 = adminDao.addFlights(flight2);
	boolean actualResult2;
	boolean expectedResult2;
	if(result2 > 0) {
	actualResult2 = true;
	} else {
	actualResult2 = false;
	}
	expectedResult2 = false;
	assertEquals(expectedResult2, actualResult2);
	
	}
	
	@Test
	public void scheduleFlightTest() throws FMSException {
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	int flightNumber = 1;
	int availableSeats = 150;
	double cost = 4000;
	String sourceAirport = "Indira Gandhi International Airport(New Delhi)";
	String destinationAirport = "Pune Airport";
	Date departureDate = null;
	Date arrivalDate = null;
	try {
	departureDate = sdf.parse("2020/11/02");
	arrivalDate = sdf.parse("2020/11/02");
	} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	
	String arrivalTime = "12.30pm";
	String departureTime = "2.30pm";
	String flightStatus = "On Time";
	
	ScheduleFlight scheduleFlight1 = new ScheduleFlight(flightNumber, availableSeats, cost, sourceAirport, destinationAirport, departureDate, arrivalDate, arrivalTime, departureTime, flightStatus);
	int result1 = adminDao.scheduleFlight(scheduleFlight1);
	boolean actualResult1;
	boolean expectedResult1;
	if(result1 > 0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1, actualResult1);
	
	ScheduleFlight flight2 = null;
	int result2 = adminDao.scheduleFlight(flight2);
	boolean actualResult2;
	boolean expectedResult2;
	if(result2 > 0) {
	actualResult2 = true;
	} else {
	actualResult2 = false;
	}
	expectedResult2 = false;
	assertEquals(expectedResult2, actualResult2);
	
	}
	
	@Test
	public void viewFlightsTest() throws FMSException {
	
	List<Flight> result1= adminDao.viewFlights();
	boolean actualResult1;
	boolean expectedResult1;
	if(result1.size() !=0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1,actualResult1);
	
	
	}
	@Test
	public void viewAirportsTest() throws FMSException {
	
	List<Airport> result1= adminDao.viewAirports();
	boolean actualResult1;
	boolean expectedResult1;
	if(result1.size() !=0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1,actualResult1);
	
	}
	
	@Test
	public void viewScheduleFlightsTest() throws FMSException {
	
	
	List<ScheduleFlight> result1= adminDao.viewScheduleFlights();
	boolean actualResult1;
	boolean expectedResult1;
	if(result1.size() !=0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1,actualResult1);
	
	}
	@Test
	public void searchFlightTest() throws FMSException {
	
	boolean actualResult3 = false;
	List<ScheduleFlight> actualResult1 = adminDao.searchFlight(0);
	String expectedResult1 = "[]";
	assertEquals(expectedResult1, actualResult1.toString());
	
	List<ScheduleFlight> actualResult2 = adminDao.searchFlight(-1);
	String expectedResult2 = "[]";
	assertEquals(expectedResult2, actualResult2.toString());
	
	List<ScheduleFlight> result3 = adminDao.searchFlight(1);
	if(result3.size() > 0) {
	actualResult3 = true;
	}
	boolean expectedResult3 = true;
	assertEquals(expectedResult3,actualResult3);
	
	}

}