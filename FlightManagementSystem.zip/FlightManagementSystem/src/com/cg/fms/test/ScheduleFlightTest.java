package com.cg.fms.test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IScheduleFlightService;
import com.cg.fms.service.ScheduleFlightService;

public class ScheduleFlightTest {
	
	IScheduleFlightService flightService = new ScheduleFlightService();
	@Test
	public void scheduleFlightTest() throws FMSException {
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	int flightNumber = 6;
	int availableSeats = 150;
	double cost = 4000;
	String sourceAirport = "Indira Gandhi International Airport(New Delhi)";
	String destinationAirport = "Pune Airport";
	Date departureDate = null;
	Date arrivalDate = null;
	try {
	departureDate = sdf.parse("2020/11/02");
	arrivalDate = sdf.parse("2020/11/02");
	} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	
	String arrivalTime = "12.30pm";
	String departureTime = "2.30pm";
	String flightStatus = "On Time";
	
	ScheduleFlight scheduleFlight1 = new ScheduleFlight(flightNumber, availableSeats, cost, sourceAirport, destinationAirport, departureDate, arrivalDate, arrivalTime, departureTime, flightStatus);
	int result1 = flightService.scheduleFlight(scheduleFlight1);
	boolean actualResult1;
	boolean expectedResult1;
	if(result1 > 0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1, actualResult1);
	
	ScheduleFlight flight2 = null;
	int result2 = flightService.scheduleFlight(flight2);
	boolean actualResult2;
	boolean expectedResult2;
	if(result2 > 0) {
	actualResult2 = true;
	} else {
	actualResult2 = false;
	}
	expectedResult2 = false;
	assertEquals(expectedResult2, actualResult2);
	
	}
	
	@Test
	public void viewScheduleFlightsTest() throws FMSException {
	
	
	List<ScheduleFlight> result1= flightService.viewScheduleFlights();
	boolean actualResult1;
	boolean expectedResult1;
	if(result1.size() !=0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1,actualResult1);
	
	}
	
	@Test
	public void searchFlightTest() throws FMSException {
	
	boolean actualResult3 = false;
	List<ScheduleFlight> actualResult1 = flightService.searchFlight(0);
	String expectedResult1 = "[]";
	assertEquals(expectedResult1, actualResult1.toString());
	
	List<ScheduleFlight> actualResult2 = flightService.searchFlight(-1);
	String expectedResult2 = "[]";
	assertEquals(expectedResult2, actualResult2.toString());
	
	List<ScheduleFlight> result3 = flightService.searchFlight(1);
	if(result3.size() > 0) {
	actualResult3 = true;
	}
	boolean expectedResult3 = true;
	assertEquals(expectedResult3,actualResult3);
	
	}
	
	@Test
	public void viewFlightDetailsTest() throws FMSException {
		ScheduleFlight result1=flightService.viewFlightDetails(1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 != null) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		ScheduleFlight result2= flightService.viewFlightDetails(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 == null) {
			actualResult2 = false;
		} else {
			actualResult2 = true;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2); 
		
	}
	
	@Test
	public void updateAvailableSeatsTest() throws FMSException {
		int result1= flightService.updateAvailableSeats(50,1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		int result2= flightService.updateAvailableSeats(100,0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
	}


}
