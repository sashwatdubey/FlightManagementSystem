package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Flight;

public interface IFlightDAO {

	public int addFlights(Flight flight) throws FMSException;
	
	public List<Flight> viewFlights() throws FMSException;
	
	public int getFlightDetails(String flightModel) throws FMSException;
}
