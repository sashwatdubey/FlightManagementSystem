package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.utility.JdbcUtility;

public class ScheduleFlightDAO implements IScheduleFlightDAO {
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	static ResultSet resultSet = null;
	
	/************************************************
	 @Description: Method to schedule flights
	 @Author: Paruchuri Sindhura
	 @arg1: ScheduleFlight scheduleFlight
	 @returns: int
	 @Exception: FMSException
	 ************************************************/
	public int scheduleFlight(ScheduleFlight scheduleFlight) throws FMSException {
		int rows =0;
		if(scheduleFlight != null && !(isFlightScheduled(scheduleFlight.getFlightNumber(),scheduleFlight.getArrivalDate(),scheduleFlight.getDepartureDate()))) {
			try {
				connection = JdbcUtility.getConnection();
				preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.SCHEDULE_FLIGHT);
				preparedStatement.setInt(1, scheduleFlight.getFlightNumber());
				preparedStatement.setInt(2, scheduleFlight.getAvailableSeats());
				preparedStatement.setDouble(3, scheduleFlight.getCost());
				preparedStatement.setString(4, scheduleFlight.getSourceAirport());
				preparedStatement.setString(5, scheduleFlight.getDestinationAirport());
				preparedStatement.setString(10, scheduleFlight.getFlightStatus());
				preparedStatement.setDate(6, new Date(scheduleFlight.getDepartureDate().getTime()));
				preparedStatement.setDate(7, new Date(scheduleFlight.getArrivalDate().getTime()));
				preparedStatement.setString(8, scheduleFlight.getArrivalTime());
				preparedStatement.setString(9, scheduleFlight.getDepartureTime());
				rows = preparedStatement.executeUpdate();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			} catch (ClassNotFoundException exception) {
				throw new FMSException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FMSException(exception.getMessage());
				}
		
			}
		}
		return rows;
	}
	
	/*****************************************************
	 @Description: method to view all the scheduled flights
	 @Author: Paruchuri Sindhura, Tejaswi Paridi
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 *****************************************************/
	public List<ScheduleFlight> viewScheduleFlights() throws FMSException {
		List<ScheduleFlight> scheduleFlights = new ArrayList<ScheduleFlight>();
		ScheduleFlight scheduleFlight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.VIEW_SCHEDULE_FLIGHTS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				scheduleFlights.add(scheduleFlight);
			}
		
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		return scheduleFlights;
	}

	/********************************************************
	 @Description: Method to search flights by flight number
	 @Author: Tejaswi Paridi
	 @arg1: int flightNumber
	 @returns: List scheduleFlights
	 @Exception: FMSException
	 ********************************************************/
	public List<ScheduleFlight> searchFlight(int flightNumber) throws FMSException {
		List<ScheduleFlight> scheduleFlights = new ArrayList<ScheduleFlight>();
		ScheduleFlight scheduleFlight = null;

		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.SEARCH_FLIGHT);
			preparedStatement.setInt(1, flightNumber);

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				scheduleFlights.add(scheduleFlight);
			}

		} catch (SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		} 
		return scheduleFlights;
	}
	
	/************************************************************
	 @Description: Method to check if flight is already scheduled
	 @Author: Paruchuri Sindhura
	 @arg1: int flightNumber
	 @arg2: java.util.Date arrivalDate
	 @arg3: java.util.Date departureDate
	 @returns: boolean
	 @Exception: FMSException
	 *************************************************************/
	public boolean isFlightScheduled(int flightNumber, java.util.Date arrivalDate, java.util.Date departureDate) throws FMSException {
		boolean found = false;
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.FLIGHT_EXISTS);
			preparedStatement.setDate(1, new Date(arrivalDate.getTime()));
			preparedStatement.setDate(2, new Date(departureDate.getTime()));
			preparedStatement.setInt(3, flightNumber);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				found = true;
			}
		} catch (SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch (ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
       return found;
	}
	
	/*********************************************************************
	 @Description : 
	 @author : Sashwat Dubey
	 @arg1 : String source
	 @arg2 : String destination
	 @arg3 : java.util.Date departureDate
	 @return : List<ScheduleFlight> 
	 @Exception : FMSException
	 */
	public List<ScheduleFlight> viewAvailableFlights(String source, String destination, java.util.Date departureDate) throws FMSException {
		List<ScheduleFlight> scheduleFlights = new ArrayList<ScheduleFlight>();
		ScheduleFlight scheduleFlight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.VIEW_AVAILABLE_FLIGHTS);
			preparedStatement.setString(1, source);
			preparedStatement.setString(2, destination);
			preparedStatement.setDate(3, new Date(departureDate.getTime()));
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				scheduleFlights.add(scheduleFlight);
			}
		
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		return scheduleFlights;
	}
	
	/*********************************************************************
	 @Description : Method to view flight details booked by the customer
	 @author : Akshitha Gampa
	 @arg1 : int flightNumber
	 @return : ScheduleFlight
	 @Exception : int flightNumber
	 */
	public ScheduleFlight viewFlightDetails(int flightNumber) throws FMSException {
		ScheduleFlight scheduleFlight = null;
		
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.VIEW_FLIGHT_DETAILS);
			preparedStatement.setInt(1, flightNumber);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				scheduleFlight= new ScheduleFlight();
				scheduleFlight.setFlightNumber(resultSet.getInt(1));
				scheduleFlight.setAvailableSeats(resultSet.getInt(2));
				scheduleFlight.setCost(resultSet.getDouble(3));
				scheduleFlight.setSourceAirport(resultSet.getString(4));
				scheduleFlight.setDestinationAirport(resultSet.getString(5));
				scheduleFlight.setDepartureDate(resultSet.getDate(6));
				scheduleFlight.setArrivalDate(resultSet.getDate(7));
				scheduleFlight.setArrivalTime(resultSet.getString(8));
				scheduleFlight.setDepartureTime(resultSet.getString(9));
				scheduleFlight.setFlightStatus(resultSet.getString(10));
				
			}
		
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		return scheduleFlight;
	}

	
	/*********************************************************************
	 @Description : Method to update available seats based on booking made
	 @author : Akshitha Gampa
	 @arg1 : int availableSeats
	 @arg2: int flightNumber
	 @return : int
	 @Exception : FMSException
	 */
	public int updateAvailableSeats(int availableSeats, int flightNumber) throws FMSException {
		int isUpdated = 0;
		if(availableSeats != 0 && flightNumber != 0) {
			try {
				connection = JdbcUtility.getConnection();
				preparedStatement = connection.prepareStatement(ScheduleFlightQueryConstants.UPDATE_AVAILABLE_SEATS);
				preparedStatement.setInt(1, availableSeats);
				preparedStatement.setInt(2, flightNumber);
				isUpdated =preparedStatement.executeUpdate();
			} catch(SQLException exception) {
				throw new FMSException(exception.getMessage());
			} catch(ClassNotFoundException exception) {
				throw new FMSException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FMSException(exception.getMessage());
				}
			}
		}
		return isUpdated;
	}

}
