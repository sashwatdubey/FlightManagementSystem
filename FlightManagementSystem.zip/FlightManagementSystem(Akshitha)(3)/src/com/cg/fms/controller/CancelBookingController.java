package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Booking;

import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;
@WebServlet("/CancelBookingController")
public class CancelBookingController  extends HttpServlet {
	static Logger logger = Logger.getLogger(CancelBookingController.class.getName());
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		IUserService service = new UserService();
		ScheduleFlight flight = null;
		int userId = 0;
		String bookingDate = null;
		boolean isDeleted = false;
		boolean isCancelled = false;
		int isUpdated = 0;
		int flightNumber = 0;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		int availableSeats = 0;
		int passengerCount = 0;
		try {
				Booking booking = service.viewBookingDetails(bookingId);
				userId = booking.getUserId();
				bookingDate = booking.getBookingDate();
				flightNumber = booking.getFlightNumber();
				passengerCount = booking.getPassengerCount();
				flight = service.viewFlightDetails(flightNumber);
				availableSeats = flight.getAvailableSeats();
				isCancelled = service.cancelBooking(bookingId);
				isDeleted = service.deletePassengers(bookingId);
				if(isCancelled && isDeleted) {
					availableSeats = flight.getAvailableSeats();
					availableSeats += (passengerCount);
					isUpdated = service.updateAvailableSeats(availableSeats, flightNumber);
					logger.info("Updated seats after cancelling flights:"+isUpdated);
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Your booking has been cancelled!');");
					out.println("location='userPage.jsp';");
					out.println("</script>");
					logger.info("Control is directed to userPage.jsp after cancelling flights");
					
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Problem ocuured while cancelling! Try again');");
					out.println("location='userPage.jsp';");
					out.println("</script>");
					logger.info("Problem occurred while cancelling booking");
				}
					
		} catch (FMSException e) {
			logger.error("Error while cancelling  bookings", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

}
